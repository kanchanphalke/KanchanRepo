package samples;

interface A{
	public void display();
	
}


