package samples;

public class ClassMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceDemo obj = new InterfaceDemo();
		obj.display();

	}

}
