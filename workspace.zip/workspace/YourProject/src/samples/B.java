package samples;

interface B{
	public void display();

	
}
