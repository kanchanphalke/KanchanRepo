package samples;


public class InterfaceDemo implements A,B{

	//@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("i am in implemented class");

	}
	

}