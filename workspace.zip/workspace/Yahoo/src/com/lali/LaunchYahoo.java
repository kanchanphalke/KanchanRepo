package com.lali;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;



//public class LaunchYahoo {
	

	//public static void main(String[] args) throws InterruptedException, FileNotFoundException {
		// TODO Auto-generated method stub
		//String currentURL = null;
		
		
//		System.setProperty("webdriver.gecko.driver", "F:\\Auto\\Driver\\geckodriver-v0.18.0-win64\\geckodriver.exe");
//		DesiredCapabilities capabilities=DesiredCapabilities.firefox();
//		capabilities.setCapability("marionette", false);
//		WebDriver driver = new FirefoxDriver(capabilities);
		//System.setProperty("webdriver.chrome.driver", "F:\\Auto\\Driver\\chromedriver_win32\\chromedriver.exe");
		//WebDriver driver = new ChromeDriver(); 
	
		
		//driver.manage().window().maximize();
//	//	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//		driver.get("https://www.yahoo.com");
//		currentURL= driver.getCurrentUrl();
//		System.out.println(currentURL);
//		driver.findElement(By.xpath(".//*[@id='uh-mail-link']/span[1]")).click();
//		Thread.sleep(2000);
//		driver.findElement(By.xpath(".//*[@id='login-username']")).sendKeys("mishra.abhineet");
//		driver.findElement(By.xpath(".//*[@id='login-signin']")).click();
//		driver.findElement(By.xpath(".//*[@id='login-passwd']")).sendKeys("abhi19mish");
//		driver.findElement(By.xpath(".//*[@id='login-signin']")).click();
//		
//	
		
		
		


	//}

//}}
